if SERVER then AddCSLuaFile() end


ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Category = "UDF"
ENT.PrintName = "Air Drone"
ENT.Spawnable = true


ENT.ForwardSpeed = 500
ENT.UpSpeed = 500
ENT.LeftRightSpeed = 500
ENT.BackSpeed = 500
ENT.Damping = 8
ENT.AngDamping = 2
ENT.SpeedMultiplier = 2
ENT.Tilt = 8
ENT.Roll = 12




function ENT:Initialize()
    if SERVER then
	    self:SetModel("models/udf/air_drone_body.mdl")
		self:SetMaterial("phoenix_storms/metalset_1-2")
		self:SetModelScale(1, 0)
		self:SetColor(Color(255,255,255))
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self.Owner = self:GetCreator()
		self.IsControlled = false
	end	
end