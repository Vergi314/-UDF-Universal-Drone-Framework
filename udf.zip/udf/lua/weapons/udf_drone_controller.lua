AddCSLuaFile()

if SERVER then
    util.AddNetworkString("UDF_DroneHUD")
end


SWEP.PrintName = "Drone Controller"
SWEP.Author = "Disperat"
SWEP.Purpose = "Control all kind of drones"
SWEP.Instructions = "Right click to take control of the drone, you need to be near it. W/A/S/D to fly/move the drone, move the mouse for rotating."
SWEP.Category = "UDF"
SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.ViewModel = "models/weapons/c_pistol.mdl"
SWEP.WorldModel = "models/weapons/w_pistol.mdl"
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.ViewModelFOV = 55


function SWEP:PrimaryAttack()
    self:SetNextPrimaryFire(CurTime() + 0.5)
    
    local owner = self:GetOwner()
    
    if self.ControlledUDFDrone and IsValid(self.ControlledUDFDrone) then
        self:EmitSound("buttons/button8.wav")
        self.ControlledUDFDrone.IsControlled = false
        net.Start("UDF_DroneHUD")
        net.WriteEntity(nil)
        net.Send(self:GetOwner())
        self.ControlledUDFDrone = nil
        owner:SetMoveType(MOVETYPE_WALK)
        return
    end
    
    local tr = util.TraceLine({
        start = owner:GetShootPos(),
        endpos = owner:GetShootPos() + owner:GetAimVector() * 150,
        filter = owner
    })
    
    if not IsValid(tr.Entity) then 
        self:EmitSound("buttons/button8.wav")
        return 
    end
    
    local ent = tr.Entity
    if not ent:IsValid() or not ent.Owner or not ent:GetClass():find("udf_") or ent.Owner ~= owner then
        self:EmitSound("buttons/button8.wav")
        return
    end
    
    self:EmitSound("buttons/button9.wav")
    self.ControlledUDFDrone = ent
    ent.IsControlled = true
    owner:SetMoveType(MOVETYPE_NONE)
	net.Start("UDF_DroneHUD")
    net.WriteEntity(ent)
    net.Send(self:GetOwner())
end

function SWEP:Think()
    if not self.ControlledUDFDrone or not IsValid(self.ControlledUDFDrone) then return end
    
    local owner = self:GetOwner()
    local drone = self.ControlledUDFDrone
    local phys = drone:GetPhysicsObject()
    if not IsValid(phys) then return end


    phys:SetDamping(drone.Damping, drone.AngDamping)

    local eyeAng = owner:EyeAngles()
    local currentAng = drone:GetAngles()


    local pitch = math.Clamp(eyeAng.p, -35, 35)
    local yaw   = eyeAng.y

    local targetRoll = 0
    local targetPitchOffset = 0

    local targetRoll = 0
    if owner:KeyDown(IN_MOVERIGHT) then
        targetRoll = -drone.Roll
    elseif owner:KeyDown(IN_MOVELEFT) then
        targetRoll = drone.Roll
    end

    local targetPitchOffset = 0
    if owner:KeyDown(IN_FORWARD) then
        targetPitchOffset = -drone.Tilt
    elseif owner:KeyDown(IN_BACK) then
        targetPitchOffset = drone.Tilt
    end

    local targetAng = Angle(pitch + targetPitchOffset, yaw, targetRoll)
    local newAng = LerpAngle(0.35, currentAng, targetAng)
    phys:SetAngles(newAng)


    local upForce = Vector(0, 0, 0)
    if owner:KeyDown(IN_JUMP) then
        upForce = upForce + Vector(0, 0, drone.UpSpeed)
    end
    if owner:KeyDown(IN_DUCK) then
        upForce = upForce + Vector(0, 0, -drone.UpSpeed)
    end
    phys:ApplyForceCenter(upForce * phys:GetMass() * FrameTime() * 60)


    local speedMultiplier = 1
    if owner:KeyDown(IN_SPEED) and drone.SpeedMultiplier then
        speedMultiplier = drone.SpeedMultiplier
    end


    local forwardForce = 0
    if owner:KeyDown(IN_FORWARD) then
        forwardForce = drone.ForwardSpeed * speedMultiplier
    elseif owner:KeyDown(IN_BACK) then
        forwardForce = -drone.BackSpeed * speedMultiplier
    end

    local rightForce = 0
    if owner:KeyDown(IN_MOVERIGHT) then
        rightForce = drone.LeftRightSpeed * speedMultiplier
    elseif owner:KeyDown(IN_MOVELEFT) then
        rightForce = -drone.LeftRightSpeed * speedMultiplier
    end


    local camAng = Angle(0, yaw, 0)
    local forwardVec = camAng:Forward() * forwardForce
    local rightVec   = camAng:Right()   * rightForce

    local force = (forwardVec + rightVec) * phys:GetMass() * FrameTime() * 60
    phys:ApplyForceCenter(force)
end




