if CLIENT then
    net.Receive("UDF_DroneHUD", function()
        local drone = net.ReadEntity()
        LocalPlayer().ControlledUDFDrone = drone
    end)


    hook.Add("HUDPaint", "DroneControllerHUD", function()
        local ply = LocalPlayer()
        local wep = ply:GetActiveWeapon()

        if not IsValid(wep) or wep:GetClass() ~= "udf_drone_controller" then return end

        local drone = ply.ControlledUDFDrone
        local displayText


        if not ply:Alive() then
            ply.ControlledUDFDrone = nil
            drone = nil
        end


        local tr = util.TraceLine({
            start = ply:GetShootPos(),
            endpos = ply:GetShootPos() + ply:GetAimVector() * 150,
            filter = ply
        })

        local lookedDrone = nil
        if IsValid(tr.Entity) and tr.Entity:GetClass():find("udf_") then
            lookedDrone = tr.Entity
        end

        if IsValid(drone) then
            displayText = "Controlled Drone: " .. (drone.PrintName or "Unknown Drone")
        elseif IsValid(lookedDrone) then
            displayText = (lookedDrone.PrintName or "Unknown Drone") .. " (Right Click to control)"
        else
            displayText = "No Drone Controlled"
        end


        surface.SetFont("DermaDefault")
        local textWidth, textHeight = surface.GetTextSize(displayText)
        local x = (ScrW() / 2) - (textWidth / 2)
        local y = ScrH() - textHeight - 50

        draw.RoundedBox(6, x - 10, y - 5, textWidth + 20, textHeight + 10, Color(255, 255, 255, 100))
        draw.SimpleText(displayText, "DermaDefault", x, y, Color(0, 0, 0, 255))
    end)


    hook.Add("PreDrawHalos", "DroneControllerHalo", function()
        local ply = LocalPlayer()
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or wep:GetClass() ~= "udf_drone_controller" then return end

        local tr = util.TraceLine({
            start = ply:GetShootPos(),
            endpos = ply:GetShootPos() + ply:GetAimVector() * 150,
            filter = ply
        })

        if IsValid(tr.Entity) and tr.Entity:GetClass():find("udf_") then
		    if tr.Entity ~= ply.ControlledUDFDrone then
                halo.Add({tr.Entity}, Color(255, 255, 255), 1, 1, 2, true, true)
			end	
        end
    end)
end
